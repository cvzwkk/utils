import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { useNetworksStore } from '@/lib/networks';
import { Compass, Search, ArrowLeft, ArrowRight, ExternalLink, ShieldAlert, Lock, ShieldCheck, Globe } from 'lucide-react';

const QUICK_LINKS = [
  { name: 'DuckDuckGo', url: 'https://duckduckgo.com', isOnion: false },
  { name: 'ProtonMail', url: 'https://protonmail.com', isOnion: false },
  { name: 'Riseup', url: 'https://riseup.net', isOnion: false },
  { name: 'Bitcoin.org', url: 'https://bitcoin.org', isOnion: false },
  { name: 'Mempool.space', url: 'https://mempool.space', isOnion: false },
  { name: 'Blockstream', url: 'https://blockstream.info', isOnion: false },
  { name: 'Electrum', url: 'https://electrum.org', isOnion: false },
  { name: 'Proton Onion', url: 'https://protonmailrmez3lotccipshtkleegetolb73fuirgj7r4o4vfu7ozyd.onion', isOnion: true },
];

export default function Browser() {
  const [url, setUrl] = useState('');
  const [inputUrl, setInputUrl] = useState('');
  const [isSearchMode, setIsSearchMode] = useState(true);
  const [frameError, setFrameError] = useState(false);
  const [isOnion, setIsOnion] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const { routingMode } = useNetworksStore();

  const handleNavigate = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setFrameError(false);
    
    let target = inputUrl.trim();
    if (!target) return;

    setIsOnion(target.includes('.onion'));

    if (isSearchMode && !target.includes('.') && !target.startsWith('http')) {
      target = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(target)}`;
    } else if (!target.startsWith('http') && !target.includes('.onion')) {
      target = `https://${target}`;
    }

    setUrl(target);
    if (!target.includes('.onion')) {
      // simulate frame error detection after a short timeout if we can't load it
      setTimeout(() => {
        // since we can't really read iframe content cross-origin easily, we just mock the error detection
        // for some well known sites that block framing
        if (target.includes('google.com') || target.includes('github.com') || target.includes('twitter.com')) {
          setFrameError(true);
        }
      }, 1500);
    }
  };

  const handleQuickLink = (link: string) => {
    setInputUrl(link);
    setIsSearchMode(false);
    // immediately navigate
    setFrameError(false);
    setIsOnion(link.includes('.onion'));
    setUrl(link);
  };

  return (
    <div className="space-y-6 h-[calc(100vh-8rem)] flex flex-col">
      <div>
        <h2 className="text-3xl font-mono font-bold tracking-tight">VANTA_BROWSER</h2>
        <p className="text-muted-foreground font-mono mt-1">In-app research and exploration</p>
      </div>

      <div className="bg-primary/10 border border-primary/20 p-4 rounded-md flex items-start gap-4 shrink-0">
        <ShieldAlert className="w-6 h-6 text-primary shrink-0 mt-0.5" />
        <div>
          <h4 className="font-mono font-bold text-primary text-sm tracking-wider">BROWSER SANDBOX LIMITATION</h4>
          <p className="text-xs text-primary/80 mt-1 leading-relaxed">
            Browser tabs cannot route iframe traffic through Tor/I2P. .onion domains are unreachable from a normal browser. Many sites refuse to be framed at all. Outbound HTTP from this app goes via your normal browser network stack.
          </p>
        </div>
      </div>

      <div className="flex gap-6 flex-1 min-h-0">
        <div className="w-64 shrink-0 space-y-4 flex flex-col">
          <Card className="bg-card/40 backdrop-blur-md border-primary/20 flex-1 flex flex-col">
            <CardHeader className="pb-3">
              <CardTitle className="font-mono text-sm">QUICK_LINKS</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto custom-scrollbar space-y-2 pr-2">
              {QUICK_LINKS.map(link => (
                <button
                  key={link.name}
                  onClick={() => handleQuickLink(link.url)}
                  className="w-full text-left p-2 rounded hover:bg-white/5 font-mono text-sm transition-colors flex items-center justify-between group"
                >
                  <span className="truncate">{link.name}</span>
                  {link.isOnion ? (
                    <Badge variant="outline" className="text-[10px] border-primary/30 text-primary bg-primary/5">ONION</Badge>
                  ) : (
                    <Globe className="w-3 h-3 text-muted-foreground group-hover:text-primary transition-colors" />
                  )}
                </button>
              ))}
            </CardContent>
          </Card>
          
          <Card className="bg-card/40 backdrop-blur-md border-primary/20 shrink-0">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-muted-foreground">Routing Mode:</span>
                <span className="text-primary">{routingMode}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-card/40 backdrop-blur-md border-primary/20 flex-1 flex flex-col overflow-hidden">
          <div className="p-2 border-b border-border/50 bg-black/40 flex items-center gap-2">
            <div className="flex gap-1">
              <Button variant="ghost" size="icon" className="h-8 w-8"><ArrowLeft className="w-4 h-4" /></Button>
              <Button variant="ghost" size="icon" className="h-8 w-8"><ArrowRight className="w-4 h-4" /></Button>
            </div>
            
            <form onSubmit={handleNavigate} className="flex-1 flex gap-2">
              <div className="relative flex-1">
                <Input 
                  value={inputUrl}
                  onChange={(e) => setInputUrl(e.target.value)}
                  placeholder={isSearchMode ? "DuckDuckGo Search or enter URL..." : "Enter URL..."}
                  className="font-mono bg-black/50 h-8 pl-8 pr-24"
                />
                <div className="absolute left-2 top-1/2 -translate-y-1/2">
                  {isSearchMode ? <Search className="w-4 h-4 text-muted-foreground" /> : <Globe className="w-4 h-4 text-muted-foreground" />}
                </div>
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
                  <Badge variant="outline" className="h-5 text-[10px] border-secondary/30 text-secondary bg-secondary/5 font-mono">
                    <ShieldCheck className="w-3 h-3 mr-1" /> SAFE
                  </Badge>
                </div>
              </div>
              <Button type="submit" size="sm" className="h-8 font-mono">GO</Button>
            </form>

            <div className="flex items-center gap-2 px-2 border-l border-border/50 ml-2">
              <span className="text-xs font-mono text-muted-foreground">SEARCH</span>
              <Switch checked={isSearchMode} onCheckedChange={setIsSearchMode} />
            </div>
          </div>

          <div className="flex-1 bg-white relative">
            {!url ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-background text-muted-foreground">
                <Compass className="w-12 h-12 mb-4 opacity-20" />
                <p className="font-mono">Enter a URL or search query to begin</p>
              </div>
            ) : isOnion ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-background p-8 text-center">
                <Lock className="w-16 h-16 mb-6 text-primary opacity-50" />
                <h3 className="text-xl font-mono font-bold text-primary mb-2">ONION SERVICE DETECTED</h3>
                <p className="font-mono text-sm text-muted-foreground max-w-md mb-8 leading-relaxed">
                  .onion domains are not resolvable on the clearnet. Your browser cannot route this traffic natively.
                </p>
                <div className="flex gap-4">
                  <Button variant="outline" className="font-mono border-primary/50 text-primary" onClick={() => window.open(`https://${url.replace('http://', '').replace('https://', '')}.ly`, '_blank', 'noopener noreferrer')}>
                    OPEN VIA TOR2WEB GATEWAY
                  </Button>
                  <Button variant="secondary" className="font-mono" onClick={() => { navigator.clipboard.writeText(url); alert('Copied'); }}>
                    COPY FOR TOR BROWSER
                  </Button>
                </div>
                <p className="text-[10px] text-destructive mt-4 max-w-md">Warning: Tor2Web gateways degrade anonymity by acting as a man-in-the-middle.</p>
              </div>
            ) : frameError ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-background p-8 text-center">
                <ShieldAlert className="w-16 h-16 mb-6 text-destructive opacity-50" />
                <h3 className="text-xl font-mono font-bold text-destructive mb-2">CONNECTION REFUSED</h3>
                <p className="font-mono text-sm text-muted-foreground max-w-md mb-8 leading-relaxed">
                  This site refused to be framed (X-Frame-Options/CSP). It must be opened in a new tab.
                </p>
                <Button className="font-mono bg-primary text-primary-foreground" onClick={() => window.open(url, '_blank', 'noopener noreferrer')}>
                  <ExternalLink className="w-4 h-4 mr-2" />
                  OPEN EXTERNALLY
                </Button>
              </div>
            ) : (
              <iframe
                ref={iframeRef}
                src={url}
                className="w-full h-full border-0 bg-white"
                sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
                referrerPolicy="no-referrer"
              />
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}