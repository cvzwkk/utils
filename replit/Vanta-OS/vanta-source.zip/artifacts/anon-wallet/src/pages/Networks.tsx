import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useNetworksStore } from '@/lib/networks';
import { Globe, Lock, KeyRound, Network, Share2, Info, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Networks() {
  const { 
    tor, i2p, yggdrasil, hyphanet, 
    routingMode, customMix,
    setNetworkState, setRoutingMode, setCustomMix
  } = useNetworksStore();

  const handleToggle = (network: 'tor' | 'i2p' | 'yggdrasil' | 'hyphanet', currentState: string) => {
    if (currentState === 'ACTIVE' || currentState === 'CONNECTING') {
      setNetworkState(network, 'DISCONNECTED');
    } else {
      setNetworkState(network, 'CONNECTING');
      setTimeout(() => {
        setNetworkState(network, 'ACTIVE');
      }, 1500 + Math.random() * 2000);
    }
  };

  const getStatusColor = (state: string) => {
    if (state === 'ACTIVE') return 'text-secondary';
    if (state === 'CONNECTING') return 'text-primary animate-pulse';
    return 'text-muted-foreground';
  };

  const NetworkCard = ({ title, id, state, icon: Icon, description }: any) => (
    <Card className={`bg-card/40 backdrop-blur-md border-${state === 'ACTIVE' ? 'secondary/50' : 'primary/20'} transition-colors`}>
      <CardHeader className="flex flex-row items-start justify-between pb-2">
        <div>
          <CardTitle className="text-lg font-mono flex items-center gap-2">
            <Icon className="w-5 h-5" />
            {title}
          </CardTitle>
          <CardDescription className="font-mono text-xs mt-1">{description}</CardDescription>
        </div>
        <Switch 
          checked={state === 'ACTIVE' || state === 'CONNECTING'} 
          onCheckedChange={() => handleToggle(id, state)}
          disabled={state === 'CONNECTING'}
        />
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mt-4">
          <div className="font-mono text-sm flex items-center gap-2">
            STATUS: <span className={getStatusColor(state)}>{state}</span>
          </div>
        </div>
        {state === 'ACTIVE' && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mt-4 space-y-2 text-xs font-mono text-muted-foreground border-t border-border/50 pt-4">
            <div className="flex justify-between"><span>Circuit Length:</span> <span className="text-primary-foreground">3 hops</span></div>
            <div className="flex justify-between"><span>Latency:</span> <span className="text-primary-foreground">{Math.floor(Math.random() * 200 + 50)}ms</span></div>
            <div className="flex justify-between"><span>Bandwidth:</span> <span className="text-primary-foreground">{(Math.random() * 5 + 1).toFixed(1)} MB/s</span></div>
            <div className="flex justify-between"><span>Exit Fingerprint:</span> <span className="text-primary-foreground truncate ml-4">{Math.random().toString(36).substring(2, 15)}...</span></div>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-mono font-bold tracking-tight">ANONYMITY_NETWORKS</h2>
          <p className="text-muted-foreground font-mono mt-1">Configure outbound routing overlay protocols</p>
        </div>
      </div>

      <div className="bg-primary/10 border border-primary/20 p-4 rounded-md flex items-start gap-4">
        <Info className="w-6 h-6 text-primary shrink-0 mt-0.5" />
        <div>
          <h4 className="font-mono font-bold text-primary text-sm tracking-wider">BROWSER SANDBOX LIMITATION</h4>
          <p className="text-xs text-primary/80 mt-1 leading-relaxed">
            Browser tabs cannot open real Tor/I2P circuits or join Yggdrasil/Hyphanet — those require system-level daemons (tor, i2pd, yggdrasil, fred). This panel models how routing decisions WOULD be made and visualizes the chosen path. Outbound HTTP from this app currently goes via your normal browser network stack.
          </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <NetworkCard title="TOR" id="tor" state={tor} icon={Lock} description="The Onion Router (Circuit-based)" />
        <NetworkCard title="I2P" id="i2p" state={i2p} icon={KeyRound} description="Invisible Internet Project (Garlic Routing)" />
        <NetworkCard title="YGGDRASIL" id="yggdrasil" state={yggdrasil} icon={Network} description="End-to-end encrypted IPv6 mesh network" />
        <NetworkCard title="HYPHANET" id="hyphanet" state={hyphanet} icon={Share2} description="Censorship-resistant distributed datastore" />
      </div>

      <Card className="bg-card/40 backdrop-blur-md border-primary/20">
        <CardHeader>
          <CardTitle className="font-mono">ROUTING_MODE</CardTitle>
          <CardDescription className="font-mono">How should requests be distributed across active networks?</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <RadioGroup value={routingMode} onValueChange={(v: any) => setRoutingMode(v)} className="grid gap-4 md:grid-cols-3">
            <div className={`flex items-center space-x-2 border rounded-md p-4 ${routingMode === 'SINGLE' ? 'border-primary bg-primary/5' : 'border-border/50 bg-black/50'}`}>
              <RadioGroupItem value="SINGLE" id="r1" />
              <Label htmlFor="r1" className="font-mono cursor-pointer">
                <div className="font-bold">SINGLE</div>
                <div className="text-xs text-muted-foreground mt-1">Pick one active network for all traffic</div>
              </Label>
            </div>
            <div className={`flex items-center space-x-2 border rounded-md p-4 ${routingMode === 'ROUND_ROBIN' ? 'border-primary bg-primary/5' : 'border-border/50 bg-black/50'}`}>
              <RadioGroupItem value="ROUND_ROBIN" id="r2" />
              <Label htmlFor="r2" className="font-mono cursor-pointer">
                <div className="font-bold">ROUND ROBIN</div>
                <div className="text-xs text-muted-foreground mt-1">Rotate sequentially per request</div>
              </Label>
            </div>
            <div className={`flex items-center space-x-2 border rounded-md p-4 ${routingMode === 'MIXED_MULTI_PATH' ? 'border-primary bg-primary/5' : 'border-border/50 bg-black/50'}`}>
              <RadioGroupItem value="MIXED_MULTI_PATH" id="r3" />
              <Label htmlFor="r3" className="font-mono cursor-pointer">
                <div className="font-bold">MIXED MULTI-PATH</div>
                <div className="text-xs text-muted-foreground mt-1">Split requests across all networks</div>
              </Label>
            </div>
          </RadioGroup>

          {routingMode === 'MIXED_MULTI_PATH' && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="pt-6 border-t border-border/50">
              <h4 className="font-mono font-bold mb-4">CUSTOM MIX WEIGHTS</h4>
              <div className="space-y-6">
                {[
                  { id: 'tor', label: 'Tor' },
                  { id: 'i2p', label: 'I2P' },
                  { id: 'yggdrasil', label: 'Yggdrasil' },
                  { id: 'hyphanet', label: 'Hyphanet' }
                ].map(({ id, label }) => {
                  const states: Record<string, string> = { tor, i2p, yggdrasil, hyphanet };
                  const state = states[id];
                  const isActive = state === 'ACTIVE';
                  return (
                    <div key={id} className={`space-y-3 ${!isActive ? 'opacity-30 pointer-events-none' : ''}`}>
                      <div className="flex justify-between">
                        <Label className="font-mono">{label}</Label>
                        <span className="font-mono text-xs">{customMix[id as keyof typeof customMix]}%</span>
                      </div>
                      <Slider 
                        value={[customMix[id as keyof typeof customMix]]} 
                        onValueChange={(val) => setCustomMix({ ...customMix, [id]: val[0] })}
                        max={100} min={0} step={1}
                        disabled={!isActive}
                      />
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
